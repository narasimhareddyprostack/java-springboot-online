package com.crm.dao;

import com.crm.model.CustomerBean;

public interface IRegistraionDao {
	public boolean saveCustomer(CustomerBean customerBean);
}
